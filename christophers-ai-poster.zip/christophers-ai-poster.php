<?php
/*
Plugin Name:      Christophers AI Poster
Plugin URI:       https://github.com/christophers12345/christophers-ai-poster
Description:      Automatically generates SEO optimized articles with the help of OpenAI.
Version:          1.0
Stable tag:       1.0
Requires at least: 6.8
Tested up to:     6.8
Requires PHP:     7.0
Author:           Christopher Smith
Author URI:       https://freewebdesigns.net/about/
License:          GPLv2 or later
License URI:      https://www.gnu.org/licenses/gpl-2.0.html
*/

/*
Contact: contact@freewebdesigns.net
GitHub Repo: https://github.com/christophers12345/christophers-ai-poster
*/

defined('ABSPATH') || exit;

class CAP_Plugin {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_cap_generate_article', [$this, 'ajax_generate_article']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
    }

    public function add_admin_menu() {
        add_options_page(
            'AI Content Poster',
            'AI Poster',
            'manage_options',
            'cap-ai-poster',
            [$this, 'render_settings_page']
        );
    }

    public function add_settings_link($links) {
        $url = esc_url(admin_url('options-general.php?page=cap-ai-poster'));
        array_unshift($links, "<a href=\"{$url}\">Settings</a>");
        return $links;
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Christopher's AI Poster</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('cap_group');
                do_settings_sections('cap-ai-poster');
                submit_button('Save Settings');
                ?>
            </form>
            <p>
                <button id="cap-generate-article" class="button button-primary">Generate Article</button>
            </p>
        </div>
        <?php
    }

    public function register_settings() {
        add_settings_section(
            'cap_main_section',
            'AI Article Generation Settings',
            '__return_empty_string',
            'cap-ai-poster'
        );

        $fields = [
            [
                'id'       => 'cap_api_key',
                'title'    => 'OpenAI API Key',
                'callback' => 'text_field',
                'desc'     => 'Enter your OpenAI API Key.',
                'sanitize' => 'sanitize_text_field',
                'type'     => 'text',
            ],
            [
                'id'       => 'cap_prompt',
                'title'    => 'Prompt',
                'callback' => 'textarea_field',
                'desc'     => 'Enter your article generation prompt.',
                'sanitize' => 'sanitize_textarea_field',
                'type'     => 'textarea',
            ],
            [
                'id'       => 'cap_model',
                'title'    => 'OpenAI Model',
                'callback' => 'text_field',
                'desc'     => 'Recommended: gpt-4o-mini',
                'sanitize' => 'sanitize_text_field',
                'type'     => 'text',
            ],
            [
                'id'       => 'cap_max_tokens',
                'title'    => 'Max Tokens',
                'callback' => 'number_field',
                'desc'     => 'Use up to 16000 for long articles.',
                'sanitize' => 'absint',
                'type'     => 'number',
            ],
        ];

        foreach ($fields as $f) {
            register_setting('cap_group', $f['id'], ['sanitize_callback' => $f['sanitize']]);
            add_settings_field(
                $f['id'],
                $f['title'],
                [$this, $f['callback']],
                'cap-ai-poster',
                'cap_main_section',
                ['label_for' => $f['id'], 'desc' => $f['desc']]
            );
        }
    }

    public function text_field($args) {
        $id = esc_attr($args['label_for']);
        $value = esc_attr(get_option($id, ''));
        $desc = wp_kses_post($args['desc']);
        echo "<input type='text' id='$id' name='$id' value='$value' class='regular-text' />";
        echo "<p class='description'><strong>$desc</strong></p>";
    }

    public function textarea_field($args) {
        $id = esc_attr($args['label_for']);
        $value = esc_textarea(get_option($id, ''));
        $desc = wp_kses_post($args['desc']);
        echo "<textarea id='$id' name='$id' rows='5' class='large-text'>$value</textarea>";
        echo "<p class='description'><strong>$desc</strong></p>";
    }

    public function number_field($args) {
        $id = esc_attr($args['label_for']);
        $value = esc_attr(get_option($id, ''));
        $desc = wp_kses_post($args['desc']);
        echo "<input type='number' id='$id' name='$id' value='$value' step='1' />";
        echo "<p class='description'><strong>$desc</strong></p>";
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'settings_page_cap-ai-poster') {
            return;
        }
        wp_enqueue_script('jquery');
        $nonce = wp_create_nonce('cap_nonce');
        $url   = admin_url('admin-ajax.php');
        $js    = "jQuery(function($){
            $('#cap-generate-article').click(function(e){
                e.preventDefault();
                var btn = $(this).prop('disabled', true).text('Generating, please wait...');
                $.post('$url', {
                    action: 'cap_generate_article',
                    nonce: '$nonce'
                }, function(resp){
                    if (resp.success) {
                        alert('Article generated. Please check your drafts.');
                        btn.text('Generate Article');
                    } else {
                        alert('Error: ' + (resp.data.message || 'Unknown error'));
                        btn.text('Generate Article');
                    }
                    btn.prop('disabled', false);
                }, 'json');
            });
        });";
        wp_add_inline_script('jquery', $js);
    }

    public function ajax_generate_article() {
        check_ajax_referer('cap_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'No permission']);
        }
        $ok = $this->generate_article();
        if ($ok) {
            wp_send_json_success();
        } else {
            wp_send_json_error(['message' => 'Failed to generate article.']);
        }
    }

    private function generate_article() {
        $api_key    = get_option('cap_api_key', '');
        $model      = get_option('cap_model', '');
        $max_tokens = (int) get_option('cap_max_tokens', '');
        $prompt     = get_option('cap_prompt', '');

        if (!$api_key || !$model || !$prompt) {
            return false;
        }

        $resp = $this->call_openai_api($api_key, $prompt, $model, $max_tokens);
        if (!$resp || empty($resp['choices'][0]['message']['content'])) {
            return false;
        }

        // Clean content from backticks and html indicators
        $content = trim($resp['choices'][0]['message']['content']);
        $content = preg_replace('/^```(?:html)?\s*/', '', $content);
        $content = preg_replace('/```$/', '', $content);
        $content = preg_replace('/^\s+|\s+$/', '', $content);

        // Extract H1 title, if any, and remove duplicates
        preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $content, $matches);
        $title = isset($matches[1]) ? wp_strip_all_tags($matches[1]) : wp_trim_words(wp_strip_all_tags($content), 8, '...');
        $content = preg_replace('/<h1[^>]*>.*?<\/h1>/is', '', $content); // remove all h1s

        $post_id = wp_insert_post([
            'post_title'   => wp_strip_all_tags($title),
            'post_content' => trim($content),
            'post_status'  => 'draft',
            'post_author'  => get_current_user_id(),
        ]);

        return !is_wp_error($post_id);
    }

    private function call_openai_api($api_key, $prompt, $model, $max_tokens) {
        $endpoint = 'https://api.openai.com/v1/chat/completions';
        $payload  = [
            'model'       => $model,
            'messages'    => [
                ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                ['role' => 'user',   'content' => $prompt],
            ],
            'max_tokens'  => $max_tokens,
            'temperature' => 0.7,
        ];

        $resp = wp_remote_post($endpoint, [
            'body'    => wp_json_encode($payload),
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . sanitize_text_field($api_key),
            ],
            'timeout' => 180,
        ]);

        if (is_wp_error($resp)) return null;
        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        if ($code !== 200) return null;
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || isset($data['error'])) return null;

        return $data;
    }
}

CAP_Plugin::get_instance();
